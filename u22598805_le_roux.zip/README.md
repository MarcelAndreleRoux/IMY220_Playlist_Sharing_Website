Install all dependencies:
npm install

Run the docker compose:
Run:
docker compose up
Delete:
docker compose down
Stop:
Ctrl + C

Run docker (if needed):
Build:
docker build -t imy220-playlist-website .
Run:
docker run -p 3000:3000 imy220-playlist-website
Stop:
Ctrl + C

MongoDB (if needed):
Username:
u22598805
Password:
IMADETHIS1234
URI Link:
mongodb+srv://u22598805:IMADETHIS1234@imy220.f7q7o.mongodb.net/?retryWrites=true&w=majority&appName=IMY220
Database Name:
IMY200_Project
