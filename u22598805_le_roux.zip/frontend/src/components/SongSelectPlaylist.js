// Song can be added to a new playlist or selected playlist
