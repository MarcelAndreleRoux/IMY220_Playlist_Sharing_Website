// This should mix playlists and songs
